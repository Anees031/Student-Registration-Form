public class Main {
    public static void main(String[] args) {
        Student model = new Student();
        RegistrationView view = new RegistrationView();
        new RegistrationController(view, model);
        view.setVisible(true);
    }
}
