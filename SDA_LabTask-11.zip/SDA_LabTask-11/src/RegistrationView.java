import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;

public class RegistrationView extends JFrame {
    private final JTextField txtName;
    private final JTextField txtFather;
    private final JComboBox<String> cbGender;
    private final JTextField txtContact;
    private final JTextField txtRollNo;
    private final JTextField txtEmail;
    private final JTextArea txtAddress;
    private final JButton btSubmit;

    public RegistrationView() {
        JPanel contentPane = new JPanel();
        setContentPane(contentPane);

        JLabel lblName = new JLabel("Name:");
        txtName = new JTextField(20);

        JLabel lblFather = new JLabel("Father's Name:");
        txtFather = new JTextField(20);

        JLabel lblGender = new JLabel("Gender:");
        cbGender = new JComboBox<>(new String[]{"Male", "Female", "Other"});

        JLabel lblContact = new JLabel("Contact:");
        txtContact = new JTextField(20);

        JLabel lblRollNo = new JLabel("Roll No:");
        txtRollNo = new JTextField(20);

        JLabel lblEmail = new JLabel("Email:");
        txtEmail = new JTextField(20);

        JLabel lblAddress = new JLabel("Address:");
        txtAddress = new JTextArea(5, 20);
        JScrollPane addressScrollPane = new JScrollPane(txtAddress);

        btSubmit = new JButton("Submit");

        GroupLayout layout = new GroupLayout(contentPane);
        contentPane.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(lblName)
                        .addComponent(lblFather)
                        .addComponent(lblGender)
                        .addComponent(lblContact)
                        .addComponent(lblRollNo)
                        .addComponent(lblEmail)
                        .addComponent(lblAddress))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(txtName)
                        .addComponent(txtFather)
                        .addComponent(cbGender)
                        .addComponent(txtContact)
                        .addComponent(txtRollNo)
                        .addComponent(txtEmail)
                        .addComponent(addressScrollPane)
                        .addComponent(btSubmit))
        );

        layout.setVerticalGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(lblName)
                        .addComponent(txtName))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(lblFather)
                        .addComponent(txtFather))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(lblGender)
                        .addComponent(cbGender))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(lblContact)
                        .addComponent(txtContact))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(lblRollNo)
                        .addComponent(txtRollNo))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(lblEmail)
                        .addComponent(txtEmail))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(lblAddress)
                        .addComponent(addressScrollPane))
                .addComponent(btSubmit)
        );

        pack();
        setTitle("Student's Registration");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public String getName() {
        return txtName.getText();
    }

    public String getFatherName() {
        return txtFather.getText();
    }

    public String getGender() {
        return cbGender.getSelectedItem().toString();
    }

    public String getContact() {
        return txtContact.getText();
    }

    public String getRollNo() {
        return txtRollNo.getText();
    }

    public String getEmail() {
        return txtEmail.getText();
    }

    public String getAddress() {
        return txtAddress.getText();
    }

    public void addSubmitListener(ActionListener listener) {
        btSubmit.addActionListener(listener);
    }

    public void addRollNoFocusListener(FocusAdapter listener) {
        txtRollNo.addFocusListener(listener);
    }

    public void setEmail(String email) {
        txtEmail.setText(email);
    }
}
