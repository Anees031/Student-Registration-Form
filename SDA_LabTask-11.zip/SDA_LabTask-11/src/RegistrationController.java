import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class RegistrationController {
    private final RegistrationView view;
    private final Student model;

    public RegistrationController(RegistrationView view, Student model) {
        this.view = view;
        this.model = model;

        this.view.addSubmitListener(new SubmitListener());
        this.view.addRollNoFocusListener(new RollNoFocusListener());
    }

    private class SubmitListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            collectInfo();
        }
    }

    private class RollNoFocusListener extends FocusAdapter {
        @Override
        public void focusLost(FocusEvent e) {
            updateEmail();
        }
    }

    private void collectInfo() {
        model.setName(view.getName());
        model.setFatherName(view.getFatherName());
        model.setGender(view.getGender());
        model.setContact(view.getContact());
        model.setRollNo(view.getRollNo());
        model.setEmail(view.getEmail());
        model.setAddress(view.getAddress());


        System.out.println("Name: " + model.getName());
        System.out.println("Father's Name: " + model.getFatherName());
        System.out.println("Gender: " + model.getGender());
        System.out.println("Contact: " + model.getContact());
        System.out.println("Roll No: " + model.getRollNo());
        System.out.println("Email: " + model.getEmail());
        System.out.println("Address: " + model.getAddress());

        JOptionPane.showMessageDialog(view, "Registration successful!");
    }

    // Method to update email based on roll number
    private void updateEmail() {
        String rollNo = view.getRollNo();
        if (rollNo.isEmpty())
            view.setEmail("");
        else {
            String[] r = rollNo.split("-");
            if (r.length == 2 && r[0].equalsIgnoreCase("P")) {
                String email = "p" + r[1] + "@pwr.nu.edu.pk";
                view.setEmail(email);
            }
        }
    }
}
